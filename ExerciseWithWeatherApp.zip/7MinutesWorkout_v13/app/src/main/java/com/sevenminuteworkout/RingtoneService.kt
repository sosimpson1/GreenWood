package com.sevenminuteworkout

import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.IBinder
import android.app.Service
import android.app.PendingIntent
import android.content.Context
import android.app.NotificationManager
import android.app.Notification
import androidx.core.app.NotificationCompat

class RingtoneService: Service(){

    companion object{
        lateinit var r:Ringtone
    }
    var id: Int = 0
    var isRunning: Boolean = false
    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startID: Int): Int{
        var state:String = intent!!.getStringExtra("extra")
        assert(state!=null)
        when(state){
            "on" -> id = 1
            "off" -> id = 0
        }
        if (!this.isRunning && id == 1){
            playAlarm()
            this.isRunning = true
            this.id = 0
            fireNotification()
        }
        else if (this.isRunning && id == 0){
            r.stop()
            this.isRunning = false
            this.id = 0
        }
        else if (!this.isRunning && id == 0){
            this.isRunning = false
            this.id = 0
        }
        else if (!this.isRunning && id == 1){
            this.isRunning = true
            this.id = 1
        }
        else{
            
        }
        playAlarm()

        return START_NOT_STICKY
    }

    private fun fireNotification() {
       var date_picker_intent:Intent = Intent(this,DatePickerActivity::class.java)
       var intent:PendingIntent = PendingIntent.
       getActivities(this,0, arrayOf(date_picker_intent),0)
        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        var notify_manager: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        var notification_n:Notification = NotificationCompat.Builder(this)
        //var notification:  N = NotificationCompat.Builder(this)
            .setContentTitle("Alarm is going off")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setSound(defaultSoundUri)
            .setContentText("Click Me")
            .setContentIntent(intent)
            .setAutoCancel(true)
            .build()
        notify_manager.notify(0,notification_n)

       }

    private fun playAlarm(){
        var alarmUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        if (alarmUri==null){
            alarmUri=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
        r = RingtoneManager.getRingtone(baseContext,alarmUri)
        r.play()
    }

    override fun onDestroy() {
        super.onDestroy()
        this.isRunning = false
    }
}