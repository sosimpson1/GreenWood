package com.sevenminuteworkout

import java.io.Serializable

data class Clouds(
    val all: Int
) : Serializable