package com.sevenminuteworkout

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.location.*
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import kotlinx.android.synthetic.main.activity_main.*
import retrofit.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.*
import retrofit.*

class MainActivity : AppCompatActivity() {
    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    /**
     * This method is auto created by Android when the Activity Class is created.
     */
    private var mProgressDialog: Dialog? = null
    @SuppressLint("ServiceCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (!isLocationEnabled()) {
            Toast.makeText(
                this,
                "Your location provider is turned off. Please turn it on.",
                Toast.LENGTH_SHORT
            ).show()

            // This will redirect you to settings from where you need to turn on the location provider.
            val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            startActivity(intent)
        }else {
            Dexter.withActivity(this)
                .withPermissions(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
                .withListener(object : MultiplePermissionsListener {
                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                        if (report!!.areAllPermissionsGranted()) {
                            requestLocationData()
                        }

                        if (report.isAnyPermissionPermanentlyDenied) {
                            Toast.makeText(
                                this@MainActivity,
                                "You have denied location permission. Please allow it is mandatory.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    override fun onPermissionRationaleShouldBeShown(
                        permissions: MutableList<PermissionRequest>?,
                        token: PermissionToken?
                    ) {
                        showRationalDialogForPermissions()
                    }
                }).onSameThread()
                .check()
        }

            llStart.setOnClickListener {
                val intent = Intent(this, ExerciseActivity::class.java)
                startActivity(intent)
            }
        buttonTime.setOnClickListener{
            val intent1 = Intent(this, DatePickerActivity::class.java)
            startActivity(intent1)
        }

    }
    private fun isLocationEnabled(): Boolean {

        // This provides access to the system location services.
        val locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }
    private fun showRationalDialogForPermissions() {
        AlertDialog.Builder(this)
            .setMessage("It Looks like you have turned off permissions required for this feature. It can be enabled under Application Settings")
            .setPositiveButton(
                "GO TO SETTINGS"
            ) { _, _ ->
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Cancel") { dialog,
                                           _ ->
                dialog.dismiss()
            }.show()
    }
    @SuppressLint("MissingPermission")
    private fun requestLocationData() {

        val mLocationRequest = LocationRequest()
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        mFusedLocationClient.requestLocationUpdates(
            mLocationRequest, mLocationCallback,
            Looper.myLooper()
        )
    }

    private val mLocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            val mLastLocation: Location = locationResult.lastLocation
            val latitude = mLastLocation.latitude
            Log.i("Current Latitude", "$latitude")

            val longitude = mLastLocation.longitude
            Log.i("Current Longitude", "$longitude")

            getLocationWeatherDetails(latitude, longitude)
        }
    }
    private fun getLocationWeatherDetails(latitude: Double, longitude: Double) {

        if (Constant.isNetworkAvailable(this@MainActivity)) {

            /**
             * Add the built-in converter factory first. This prevents overriding its
             * behavior but also ensures correct behavior when using converters that consume all types.
             */
            val retrofit: Retrofit = Retrofit.Builder()
                // API base URL.
                .baseUrl(Constant.BASE_URL)
                /** Add converter factory for serialization and deserialization of objects. */
                /**
                 * Create an instance using a default {@link Gson} instance for conversion. Encoding to JSON and
                 * decoding from JSON (when no charset is specified by a header) will use UTF-8.
                 */
                .addConverterFactory(GsonConverterFactory.create())
                /** Create the Retrofit instances. */
                .build()

            /**
             * Here we map the service interface in which we declares the end point and the API type
             *i.e GET, POST and so on along with the request parameter which are required.
             */
            val service: WeatherService =
                retrofit.create<WeatherService>(WeatherService::class.java)

            /** An invocation of a Retrofit method that sends a request to a web-server and returns a response.
             * Here we pass the required param in the service
             */
            val listCall: Call<WeatherResponse> = service.getWeather(
                latitude, longitude, Constant.METRIC_UNIT, Constant.APP_ID
            )

            showCustomProgressDialog() // Used to show the progress dialog

            // Callback methods are executed using the Retrofit callback executor.
            listCall.enqueue(object : Callback<WeatherResponse> {
                @SuppressLint("SetTextI18n")
                override fun onResponse(
                    response: retrofit.Response<WeatherResponse>,
                    retrofit: Retrofit
                ) {

                    // Check weather the response is success or not.
                    if (response.isSuccess) {

                        hideProgressDialog() // Hides the progress dialog

                        /** The de-serialized response body of a successful response. */
                        val weatherList: WeatherResponse = response.body()
                        Log.i("Response Result", "$weatherList")

                        // TODO (STEP 6: Call the setup UI method here and pass the response object as a parameter to it to get the individual values.)
                        // START
                        setupUI(weatherList)
                        // END
                    } else {
                        // If the response is not success then we check the response code.
                        val sc = response.code()
                        when (sc) {
                            400 -> {
                                Log.e("Error 400", "Bad Request")
                            }
                            404 -> {
                                Log.e("Error 404", "Not Found")
                            }
                            else -> {
                                Log.e("Error", "Generic Error")
                            }
                        }
                    }
                }

                override fun onFailure(t: Throwable) {
                    hideProgressDialog() // Hides the progress dialog
                    Log.e("Errorrrrr", t.message.toString())
                }
            })
        } else {
            Toast.makeText(
                this@MainActivity,
                "No internet connection available.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
//                /**
//                 * Method is used to show the Custom Progress Dialog.
//                 */
                private fun showCustomProgressDialog() {
                    mProgressDialog = Dialog(this)

                    /*Set the screen content from a layout resource.
        The resource will be inflated, adding all top-level views to the screen.*/
                    mProgressDialog!!.setContentView(R.layout.dialog_custom_progress)

                    //Start the dialog and display it on screen.
                    mProgressDialog!!.show()
                }

                /**
                 * This function is used to dismiss the progress dialog if it is visible to user.
                 */
                private fun hideProgressDialog() {
                    if (mProgressDialog != null) {
                        mProgressDialog!!.dismiss()
                    }
                }

                // TODO (STEP 5: We have set the values to the UI and also added some required methods for Unit and Time below.)
                /**
                 * Function is used to set the result in the UI elements.
                 */
                private fun setupUI(weatherList: WeatherResponse) {

                    // For loop to get the required data. And all are populated in the UI.
                    for (z in weatherList.weather.indices) {
                        Log.i("NAMEEEEEEEE", weatherList.weather[z].main)

                        tv_main.text = weatherList.weather[z].main
                        tv_main_description.text = weatherList.weather[z].description
                        tv_temp.text =
                            weatherList.main.temp.toString() + getUnit(application.resources.configuration.locales.toString())
                        tv_humidity.text = weatherList.main.humidity.toString() + " per cent"
                        tv_min.text = weatherList.main.temp_min.toString() + " min"
                        tv_max.text = weatherList.main.temp_max.toString() + " max"
                        tv_speed.text = weatherList.wind.speed.toString()
                        tv_sunrise_time.text = unixTime(weatherList.sys.sunrise.toLong())
                        tv_sunset_time.text = unixTime(weatherList.sys.sunset.toLong())


                        // Here we update the main icon
                        when (weatherList.weather[z].icon) {
                            "01d" -> iv_main.setImageResource(R.drawable.sunny)
                            "02d" -> iv_main.setImageResource(R.drawable.cloud)
                            "03d" -> iv_main.setImageResource(R.drawable.cloud)
                            "04d" -> iv_main.setImageResource(R.drawable.cloud)
                            "04n" -> iv_main.setImageResource(R.drawable.cloud)
                            "10d" -> iv_main.setImageResource(R.drawable.rain)
                            "11d" -> iv_main.setImageResource(R.drawable.storm)
                            "13d" -> iv_main.setImageResource(R.drawable.snowflake)
                            "01n" -> iv_main.setImageResource(R.drawable.cloud)
                            "02n" -> iv_main.setImageResource(R.drawable.cloud)
                            "03n" -> iv_main.setImageResource(R.drawable.cloud)
                            "10n" -> iv_main.setImageResource(R.drawable.cloud)
                            "11n" -> iv_main.setImageResource(R.drawable.rain)
                            "13n" -> iv_main.setImageResource(R.drawable.snowflake)
                        }
                    }
                }

                /**
                 * Function is used to get the temperature unit value.
                 */
                private fun getUnit(value: String): String? {
                    Log.i("unitttttt", value)
                    var value = "°C"
                    if ("US" == value || "LR" == value || "MM" == value) {
                        value = "°F"
                    }
                    return value
                }

                /**
                 * The function is used to get the formatted time based on the Format and the LOCALE we pass to it.
                 */
                private fun unixTime(timex: Long): String? {
                    val date = Date(timex * 1000L)
                    @SuppressLint("SimpleDateFormat") val sdf =
                        SimpleDateFormat("HH:mm:ss")
                    sdf.timeZone = TimeZone.getDefault()
                    return sdf.format(date)
                }



            }


